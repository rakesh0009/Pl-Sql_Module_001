Question  1.	List tables in your schema and check for existence of DEPT, EMP and SALGERADE tables?

SQL> select *from tab;

TNAME                          TABTYPE  CLUSTERID
------------------------------ ------- ----------
BIN$DHRgOMgJRWe9Vsc3aP7XJw==$0 TABLE
BIN$RfQRWW+rSVmZ3AJDfrFEYg==$0 TABLE
BIN$XKGWxiy6Suyg+GCcrfPayg==$0 TABLE
BIN$uK0NH9FrT1OKYE3DW/JFCA==$0 TABLE
BONUS                          TABLE
DEPT                           TABLE
EMP                            TABLE
EMPLOYEE                       TABLE
SALGRADE                       TABLE

9 rows selected.
Question  3.	List all columns and all rows from DEPT

SQL> desc dept
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------
 DEPTNO                                    NOT NULL NUMBER(2)
 DNAME                                              VARCHAR2(14)
 LOC                                                VARCHAR2(13)


SQL> select *from dept;

    DEPTNO DNAME          LOC
---------- -------------- -------------
        10 ACCOUNTING     NEW YORK
        20 RESEARCH       DALLAS
        30 SALES          CHICAGO
        40 OPERATIONS     BOSTON


Question 4.	List all columns and all rows from EMP

   SQL> desc emp;
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------
 EMPNO                                     NOT NULL NUMBER(4)
 ENAME                                              VARCHAR2(10)
 JOB                                                VARCHAR2(9)
 MGR                                                NUMBER(4)
 HIREDATE                                           DATE
 SAL                                                NUMBER(7,2)
 COMM                                               NUMBER(7,2)
 DEPTNO                                    NOT NULL NUMBER(2)

SQL> select *from emp;

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7839 KING       PRESIDENT            17-NOV-81       5000
        10

      7698 BLAKE      MANAGER         7839 01-MAY-81       2850
        30

      7782 CLARK      MANAGER         7839 09-JUN-81       2450
        10


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7566 JONES      MANAGER         7839 02-APR-81       2975
        20

      7654 MARTIN     SALESMAN        7698 28-SEP-81       1250       1400
        30

      7499 ALLEN      SALESMAN        7698 20-FEB-81       1600        300
        30


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7844 TURNER     SALESMAN        7698 08-SEP-81       1500          0
        30

      7900 JAMES      CLERK           7698 03-DEC-81        950
        30

      7521 WARD       SALESMAN        7698 22-FEB-81       1250        500
        30


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7902 FORD       ANALYST         7566 03-DEC-81       3000
        20

      7369 SMITH      CLERK           7902 17-DEC-80        800
        20

      7788 SCOTT      ANALYST         7566 09-DEC-82       3000
        20


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7876 ADAMS      CLERK           7788 12-JAN-83       1100
        20

      7934 MILLER     CLERK           7782 23-JAN-82       1300
        10


14 rows selected.

Question  5.	List all columns and all rows from SALGRADE

SQL> desc SALGRADE;
 Name                                      Null?    Type
 ----------------------------------------- -------- ----------------------------
 GRADE                                              NUMBER
 LOSAL                                              NUMBER
 HISAL                                              NUMBER

SQL> select *from SALGRADE;

     GRADE      LOSAL      HISAL
---------- ---------- ----------
         1        700       1200
         2       1201       1400
         3       1401       2000
         4       2001       3000
         5       3001       9999



Question  6.	List employee number, name and salary from employee table
SQL> select EMPNO, ENAME, SAl from emp ;

     EMPNO ENAME             SAL
---------- ---------- ----------
      7839 KING             5000
      7698 BLAKE            2850
      7782 CLARK            2450
      7566 JONES            2975
      7654 MARTIN           1250
      7499 ALLEN            1600
      7844 TURNER           1500
      7900 JAMES             950
      7521 WARD             1250
      7902 FORD             3000
      7369 SMITH             800

     EMPNO ENAME             SAL
---------- ---------- ----------
      7788 SCOTT            3000
      7876 ADAMS            1100
      7934 MILLER           1300

14 rows selected.

Question 7.	List employee number, name and salary from employee table where salary is > 3000

SQL> select EMPNO, ENAME, SAl from emp  where sal > 3000;

     EMPNO ENAME             SAL
---------- ---------- ----------
      7839 KING             5000


Question  8.	List employees joined after year 1981

SQL> SELECT *from emp where EXTRACT(Year FROM HIREDATE)>1981;

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7788 SCOTT      ANALYST         7566 09-DEC-82       3000
        20

      7876 ADAMS      CLERK           7788 12-JAN-83       1100
        20

      7934 MILLER     CLERK           7782 23-JAN-82       1300
        10

Question 9.	List all clerks (JOB = �CLERK�)

SQL> SELECT *from emp where job='CLERK';

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7900 JAMES      CLERK           7698 03-DEC-81        950
        30

      7369 SMITH      CLERK           7902 17-DEC-80        800
        20

      7876 ADAMS      CLERK           7788 12-JAN-83       1100
        20


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7934 MILLER     CLERK           7782 23-JAN-82       1300
        10

Question 10.	List employees in the ascending order of salary

SQL> SELECT *from emp order by sal asc;

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7369 SMITH      CLERK           7902 17-DEC-80        800
        20

      7900 JAMES      CLERK           7698 03-DEC-81        950
        30

      7876 ADAMS      CLERK           7788 12-JAN-83       1100
        20


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7521 WARD       SALESMAN        7698 22-FEB-81       1250        500
        30

      7654 MARTIN     SALESMAN        7698 28-SEP-81       1250       1400
        30

      7934 MILLER     CLERK           7782 23-JAN-82       1300
        10


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7844 TURNER     SALESMAN        7698 08-SEP-81       1500          0
        30

      7499 ALLEN      SALESMAN        7698 20-FEB-81       1600        300
        30

      7782 CLARK      MANAGER         7839 09-JUN-81       2450
        10


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7698 BLAKE      MANAGER         7839 01-MAY-81       2850
        30

      7566 JONES      MANAGER         7839 02-APR-81       2975
        20

      7902 FORD       ANALYST         7566 03-DEC-81       3000
        20


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7788 SCOTT      ANALYST         7566 09-DEC-82       3000
        20

      7839 KING       PRESIDENT            17-NOV-81       5000
        10


14 rows selected.


Question 11.	List employees in ascending order of job within descending order of deptno
  
     SQL> SELECT *from emp order by HIREDATE asc, DEPTNO DESC;

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7369 SMITH      CLERK           7902 17-DEC-80        800
        20

      7499 ALLEN      SALESMAN        7698 20-FEB-81       1600        300
        30

      7521 WARD       SALESMAN        7698 22-FEB-81       1250        500
        30


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7566 JONES      MANAGER         7839 02-APR-81       2975
        20

      7698 BLAKE      MANAGER         7839 01-MAY-81       2850
        30

      7782 CLARK      MANAGER         7839 09-JUN-81       2450
        10


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7844 TURNER     SALESMAN        7698 08-SEP-81       1500          0
        30

      7654 MARTIN     SALESMAN        7698 28-SEP-81       1250       1400
        30

      7839 KING       PRESIDENT            17-NOV-81       5000
        10


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7900 JAMES      CLERK           7698 03-DEC-81        950
        30

      7902 FORD       ANALYST         7566 03-DEC-81       3000
        20

      7934 MILLER     CLERK           7782 23-JAN-82       1300
        10


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7788 SCOTT      ANALYST         7566 09-DEC-82       3000
        20

      7876 ADAMS      CLERK           7788 12-JAN-83       1100
        20


14 rows selected.

Question 12.	List distinct departments from employee table


SQL> select distinct(DEPTNO) from emp;

    DEPTNO
----------
        30
        20
        10


Question 13.	List distinct jobs in each department from employee table


SQL> select distinct(e.JOB),d.DNAME,d.deptno from emp e,dept d where e.deptno=d.deptno;

JOB       DNAME              DEPTNO
--------- -------------- ----------
ANALYST   RESEARCH               20
MANAGER   SALES                  30
MANAGER   ACCOUNTING             10
SALESMAN  SALES                  30
PRESIDENT ACCOUNTING             10
CLERK     RESEARCH               20
CLERK     ACCOUNTING             10
CLERK     SALES                  30
MANAGER   RESEARCH               20

9 rows selected.

Question 14.	List name, salary and annual salary in the descending order of annual salary � annual salary is a computed column � SAL * 12 


SQL> select empno,ename,job ,(sal*12) as annual_sal from emp  order by   sal asc;

     EMPNO ENAME      JOB       ANNUAL_SAL
---------- ---------- --------- ----------
      7369 SMITH      CLERK           9600
      7900 JAMES      CLERK          11400
      7876 ADAMS      CLERK          13200
      7521 WARD       SALESMAN       15000
      7654 MARTIN     SALESMAN       15000
      7934 MILLER     CLERK          15600
      7844 TURNER     SALESMAN       18000
      7499 ALLEN      SALESMAN       19200
      7782 CLARK      MANAGER        29400
      7698 BLAKE      MANAGER        34200
      7566 JONES      MANAGER        35700

     EMPNO ENAME      JOB       ANNUAL_SAL
---------- ---------- --------- ----------
      7902 FORD       ANALYST        36000
      7788 SCOTT      ANALYST        36000
      7839 KING       PRESIDENT      60000

14 rows selected.

Question 15.	List employees whose salary is not in the range of 2000 and 3000

  
SQL> select empno,ename,job ,sal from emp  where (sal <2000 or sal>3000);

     EMPNO ENAME      JOB              SAL
---------- ---------- --------- ----------
      7839 KING       PRESIDENT       5000
      7654 MARTIN     SALESMAN        1250
      7499 ALLEN      SALESMAN        1600
      7844 TURNER     SALESMAN        1500
      7900 JAMES      CLERK            950
      7521 WARD       SALESMAN        1250
      7369 SMITH      CLERK            800
      7876 ADAMS      CLERK           1100
      7934 MILLER     CLERK           1300

9 rows selected.

Question 16.	List name and the deptno for all employees who are NOT members of departments 10 and 20


SQL> select empno,ename,job ,sal,deptno from emp  where (deptno <10 or deptno <20);

     EMPNO ENAME      JOB              SAL     DEPTNO
---------- ---------- --------- ---------- ----------
      7839 KING       PRESIDENT       5000         10
      7782 CLARK      MANAGER         2450         10
      7934 MILLER     CLERK           1300         10



Question 17.	List employees for whom COMM is not applicable

SQL> select * from emp where comm is null;

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7839 KING       PRESIDENT            17-NOV-81       5000
        10

      7698 BLAKE      MANAGER         7839 01-MAY-81       2850
        30

      7782 CLARK      MANAGER         7839 09-JUN-81       2450
        10


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7566 JONES      MANAGER         7839 02-APR-81       2975
        20

      7900 JAMES      CLERK           7698 03-DEC-81        950
        30

      7902 FORD       ANALYST         7566 03-DEC-81       3000
        20


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7369 SMITH      CLERK           7902 17-DEC-80        800
        20

      7788 SCOTT      ANALYST         7566 09-DEC-82       3000
        20

      7876 ADAMS      CLERK           7788 12-JAN-83       1100
        20


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7934 MILLER     CLERK           7782 23-JAN-82       1300
        10


10 rows selected.


Question 18.	List employees for whom COMM is applicable 

SQL> select * from emp where comm is not null;

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7654 MARTIN     SALESMAN        7698 28-SEP-81       1250       1400
        30

      7499 ALLEN      SALESMAN        7698 20-FEB-81       1600        300
        30

      7844 TURNER     SALESMAN        7698 08-SEP-81       1500          0
        30


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7521 WARD       SALESMAN        7698 22-FEB-81       1250        500
        30


Question 19.	List employees in ascending order of COMM and note how NULLs are sorted

SQL> select * from emp order by comm asc;

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7844 TURNER     SALESMAN        7698 08-SEP-81       1500          0
        30

      7499 ALLEN      SALESMAN        7698 20-FEB-81       1600        300
        30

      7521 WARD       SALESMAN        7698 22-FEB-81       1250        500
        30


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7654 MARTIN     SALESMAN        7698 28-SEP-81       1250       1400
        30

      7934 MILLER     CLERK           7782 23-JAN-82       1300
        10

      7839 KING       PRESIDENT            17-NOV-81       5000
        10


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7902 FORD       ANALYST         7566 03-DEC-81       3000
        20

      7369 SMITH      CLERK           7902 17-DEC-80        800
        20

      7788 SCOTT      ANALYST         7566 09-DEC-82       3000
        20


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7876 ADAMS      CLERK           7788 12-JAN-83       1100
        20

      7566 JONES      MANAGER         7839 02-APR-81       2975
        20

      7782 CLARK      MANAGER         7839 09-JUN-81       2450
        10


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7698 BLAKE      MANAGER         7839 01-MAY-81       2850
        30

      7900 JAMES      CLERK           7698 03-DEC-81        950
        30


14 rows selected.


Question 20.	List employees whose names start with ��SMITH�


SQL> select *from emp where ename like 'SMITH%';

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7369 SMITH      CLERK           7902 17-DEC-80        800
        20


Question 20.	List employees whose name contain the �MI� 


SQL> select * from emp  where ENAME LIKE '%MI%';

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7369 SMITH      CLERK           7902 17-DEC-80        800
        20

      7934 MILLER     CLERK           7782 23-JAN-82       1300
        10

Question 21.	List employees whose name start with an _ (underscore) char. 


SQL> select * from emp  where ENAME LIKE '\_%';

no rows selected

Question 22.	List all employees joined between two given dates.


 SQL> select * FROM emp
  2  WHERE trunc(HIREDATE)
  3  BETWEEN trunc(TO_DATE('01-01-1982','MM-DD-YYYY')) AND trunc(TO_DATE('03-11-1983','MM-DD-YYYY'));

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7788 SCOTT      ANALYST         7566 09-DEC-82       3000
        20

      7876 ADAMS      CLERK           7788 12-JAN-83       1100
        20

      7934 MILLER     CLERK           7782 23-JAN-82       1300
        10

Question 23.	List all clerks in deptno 10


SQL> select *from emp where deptno='10';

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7839 KING       PRESIDENT            17-NOV-81       5000
        10

      7782 CLARK      MANAGER         7839 09-JUN-81       2450
        10

      7934 MILLER     CLERK           7782 23-JAN-82       1300
        10

Questio 24.	List total/sum, maximum, minimum, average of salary from employee table

     SQL> select sum(sal) from emp;

  SUM(SAL)
----------
     29025
SQL> select max(sal) from emp;

  MAX(SAL)
----------
      5000
SQL> select min(sal) from emp;

  MIN(SAL)
----------
       800

SQL> select avg(sal) from emp;

  AVG(SAL)
----------
2073.21429


Question 25.	List average and count of commission of all employees in department 10

     >>>>>>>>  For Average(Sal)
 SQL> select count(distinct(empno)),avg(sal) from emp group by deptno having deptno='10';

COUNT(DISTINCT(EMPNO))   AVG(SAL)
---------------------- ----------
                     3 2916.66667

Question 26.	List department wise no of employees and total salary

 
QL> select sum(sal) as total_sum , count(distinct(empno)) number_EMP from emp group by deptno having deptno='10';

 TOTAL_SUM NUMBER_EMP
---------- ----------
      8750          3

Question 27 .  	List total salary Job wise within each department
SQL> select sum(sal) as total_sum, deptno  from emp group by deptno;

 TOTAL_SUM     DEPTNO
---------- ----------
      9400         30
     10875         20
      8750         10
Question 28.  List department wise total salary for deptno 10 and 20 only

  
SQL> select sum(sal) as total_sum, deptno  from emp group by deptno having deptno='10' or deptno='20';

 TOTAL_SUM     DEPTNO
---------- ----------
     10875         20
      8750         10

 Question 29.	List department wise total salary where total salary is > 6000

SQL> select sum(sal) as total_sum, deptno  from emp group by deptno having sum(sal)>6000;

 TOTAL_SUM     DEPTNO
---------- ----------
      9400         30
     10875         20
      8750         10

Question 30.	SELECT COUNT(*), COUNT(COMM) FROM EMP; - explain why the two counts are different

  SQL> SELECT COUNT(*), COUNT(COMM) FROM EMP;

  COUNT(*) COUNT(COMM)
---------- -----------
        14           4
   
  COUNT(*) 14  --count the row with null or without null
COUNT(COMM) 4  --count the row without null



+++++++++++++++++++++++++++++++++++++SubQuery   ++++++++++++++++++++++++++++++++++++++++++++++++

Question 1.	List employees whose job is same as that of �SMITH�


SQL> select *from emp where job=(select job from emp where ename='SMITH');

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7900 JAMES      CLERK           7698 03-DEC-81        950
        30

      7369 SMITH      CLERK           7902 17-DEC-80        800
        20

      7876 ADAMS      CLERK           7788 12-JAN-83       1100
        20


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7934 MILLER     CLERK           7782 23-JAN-82       1300
        10


  Question 2.	List employees who have joined after �ADAM�

   
SQL> select *FROM emp where ename='ADAMS';

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7876 ADAMS      CLERK           7788 12-JAN-83       1100
        20


SQL> select HIREDATE FROM emp where ename='ADAMS';

HIREDATE
---------
12-JAN-83

SQL> select *from emp where HIREDATE < (select HIREDATE FROM emp where ename='ADAMS');

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7839 KING       PRESIDENT            17-NOV-81       5000
        10

      7698 BLAKE      MANAGER         7839 01-MAY-81       2850
        30

      7782 CLARK      MANAGER         7839 09-JUN-81       2450
        10


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7566 JONES      MANAGER         7839 02-APR-81       2975
        20

      7654 MARTIN     SALESMAN        7698 28-SEP-81       1250       1400
        30

      7499 ALLEN      SALESMAN        7698 20-FEB-81       1600        300
        30


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7844 TURNER     SALESMAN        7698 08-SEP-81       1500          0
        30

      7900 JAMES      CLERK           7698 03-DEC-81        950
        30

      7521 WARD       SALESMAN        7698 22-FEB-81       1250        500
        30


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7902 FORD       ANALYST         7566 03-DEC-81       3000
        20

      7369 SMITH      CLERK           7902 17-DEC-80        800
        20

      7788 SCOTT      ANALYST         7566 09-DEC-82       3000
        20


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7934 MILLER     CLERK           7782 23-JAN-82       1300
        10


13 rows selected.

  
Question 3.	List employees who salary is greater than �SCOTT�s salary


SQL> select * from emp where sal >(select sal from emp where ename='SCOTT');

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7839 KING       PRESIDENT            17-NOV-81       5000
        10

Question 4.	List employees getting the maximum salary

SQL> select *from emp where sal=(select max(sal) from emp);

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7839 KING       PRESIDENT            17-NOV-81       5000
        10


Question 5.	List employees show salary is > the max salary of all employees in deptno 30


SQL> select *from emp where sal>(select max(sal) from emp where deptno='30');

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7839 KING       PRESIDENT            17-NOV-81       5000
        10

      7566 JONES      MANAGER         7839 02-APR-81       2975
        20

      7902 FORD       ANALYST         7566 03-DEC-81       3000
        20


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7788 SCOTT      ANALYST         7566 09-DEC-82       3000
        20


Question 6.	List all employees whose deptno and Job are same as that of employee with empno 7788.

  

SQL> select *from emp where deptno=(select deptno from emp where empno='7788') and job=(select job from emp where empno='7788');

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7902 FORD       ANALYST         7566 03-DEC-81       3000
        20

      7788 SCOTT      ANALYST         7566 09-DEC-82       3000
        20

Question 7.	List employee who are not managers

SQL> select *from emp where job in(select job from emp where job!='MANAGER');

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7839 KING       PRESIDENT            17-NOV-81       5000
        10

      7521 WARD       SALESMAN        7698 22-FEB-81       1250        500
        30

      7844 TURNER     SALESMAN        7698 08-SEP-81       1500          0
        30


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7499 ALLEN      SALESMAN        7698 20-FEB-81       1600        300
        30

      7654 MARTIN     SALESMAN        7698 28-SEP-81       1250       1400
        30

      7934 MILLER     CLERK           7782 23-JAN-82       1300
        10


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7876 ADAMS      CLERK           7788 12-JAN-83       1100
        20

      7369 SMITH      CLERK           7902 17-DEC-80        800
        20

      7900 JAMES      CLERK           7698 03-DEC-81        950
        30


     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7788 SCOTT      ANALYST         7566 09-DEC-82       3000
        20

      7902 FORD       ANALYST         7566 03-DEC-81       3000
        20


11 rows selected.


Question 8.	List all managers

SQL> select * from emp where job='MANAGER';

     EMPNO ENAME      JOB              MGR HIREDATE         SAL       COMM
---------- ---------- --------- ---------- --------- ---------- ----------
    DEPTNO
----------
      7698 BLAKE      MANAGER         7839 01-MAY-81       2850
        30

      7782 CLARK      MANAGER         7839 09-JUN-81       2450
        10

      7566 JONES      MANAGER         7839 02-APR-81       2975
        20

Question 9.	List all employees who earn(salary) more than the average salary in their own department

 
SQL> select *from emp where sal in(select avg(sal) from emp group by deptno) ;

no rows selected

Question 10.	List employees whose salary is greater than their manager�s salary

SQL> Select * from emp e inner join emp m on e.EMPNO = m.EMPNO where e.sal < m.sal;

no rows selected

Question 11.	List details of departments from DEPT table for which there are no employees in EMP table 

   SQL> select * from dept where deptno not in(select d.deptno from dept d , emp e where e.deptno=d.deptno);

    DEPTNO DNAME          LOC
---------- -------------- -------------
        40 OPERATIONS     BOSTON
